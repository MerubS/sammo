﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Foodie_menu
{
    public partial class homeFood1 : UserControl
    {
        myCart obj = new myCart();
        public homeFood1()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        public void work()              /// To MARK/UnMARK prevoiusly saved favorites
        {
            pulaoFav_button.BackColor = Color.White;
            daalFav_button.BackColor = Color.White;
            roastFav_button.BackColor = Color.White;
            karahiFav_button.BackColor = Color.White;
            haleemFav_button.BackColor = Color.White;
            foreach (string fav in myCart.favorites)
            {
                if (fav=="Pulao") { pulaoFav_button.BackColor = Color.OrangeRed; }
                if (fav == "Daal Mix"){ daalFav_button.BackColor = Color.OrangeRed;  }
                if (fav == "Chicken Roast"){ roastFav_button.BackColor = Color.OrangeRed;}
                if (fav == "Mutton Karahi") { karahiFav_button.BackColor = Color.OrangeRed; }
                if (fav == "Haleem" ){ haleemFav_button.BackColor = Color.OrangeRed; }
         }

            if (obj.GET_Reviews(5) <= 5) { pulao_Rating.Value = obj.GET_Reviews(5); }
            else { pulao_Rating.Value = 5; }
            if (obj.GET_Reviews(6) <= 5) { daal_Rating.Value = obj.GET_Reviews(6); }
            else { daal_Rating.Value = 5; }
            if (obj.GET_Reviews(7) <= 5) {roast_Rating.Value = obj.GET_Reviews(7); }
            else { roast_Rating.Value = 5; }
            if (obj.GET_Reviews(8) <= 5) { karahi_Rating.Value = obj.GET_Reviews(8); }
            else { karahi_Rating.Value = 5; }
            if (obj.GET_Reviews(9) <= 5) { haleem_Rating.Value = obj.GET_Reviews(9); }
            else { haleem_Rating.Value = 5; }
        }
        

        

        ///////////////////// Add to cart buttons ///////////////////
        private void pulao_buttton_Click(object sender, EventArgs e)
        {
         
            obj.addItem("Pulao");
            if(myCart.index1 < 20)
               flag_1.Visible = true;
            timer1.Start();

        }

        private void daal_button_Click(object sender, EventArgs e)
        {
        
            obj.addItem("Daal Mix");
            if (myCart.index1 < 20)
               flag_2.Visible = true;
            timer1.Start();
        }

        private void roast_button_Click(object sender, EventArgs e)
        {
        
            obj.addItem("Chicken Roast");
            if (myCart.index1 < 20)
                flag_3.Visible = true;
            timer1.Start();
        }

        private void karahi_button_Click(object sender, EventArgs e)
        {
            
            obj.addItem("Mutton Karahi");
            if (myCart.index1 < 20)
                flag_4.Visible = true;
            timer1.Start();
        }

        private void haleem_button_Click(object sender, EventArgs e)
        {
            
            obj.addItem("Haleem");
            if (myCart.index1 < 20)
                flag_5.Visible = true;
            timer1.Start();
        }

        //////////////////////        ADD TO FAVORITES BUTTONS        ////////////////////////

        private void pulaoFav_button_Click_1(object sender, EventArgs e)
        {
            if (pulaoFav_button.BackColor == Color.White)
            {
                pulaoFav_button.BackColor = Color.OrangeRed;
                obj.addFavorite("Pulao");
                L_1.Visible = true;
                timer1.Start();
            }
            else
            {
                pulaoFav_button.BackColor = Color.White;
                obj.removeFavorite("Pulao");
            }
        }
        private void daalFav_button_Click(object sender, EventArgs e)
        {
           
            if (daalFav_button.BackColor == Color.White)
            {
                daalFav_button.BackColor = Color.OrangeRed;
                obj.addFavorite("Daal Mix");
                L_2.Visible = true;
                timer1.Start();

            }
            else
            {
                daalFav_button.BackColor = Color.White;
                obj.removeFavorite("Daal Mix");
            }
        }

        private void roastFav_button_Click(object sender, EventArgs e)
        {
            
            if (roastFav_button.BackColor == Color.White)
            {
                roastFav_button.BackColor = Color.OrangeRed;
                obj.addFavorite("Chicken Roast");
                L_3.Visible = true;
                timer1.Start();
            }
            else
            {
                roastFav_button.BackColor = Color.White;
                obj.removeFavorite("Chicken Karahi");
            }
        }

        private void karahiFav_button_Click(object sender, EventArgs e)
        {
            
            if (karahiFav_button.BackColor == Color.White)
            {
                karahiFav_button.BackColor = Color.OrangeRed;
                obj.addFavorite("Mutton Karahi");
                L_4.Visible = true;
                timer1.Start();
            }
            else
            {
                karahiFav_button.BackColor = Color.White;
                obj.removeFavorite("Mutton Karahi");
            }
        }

        private void haleemFav_button_Click(object sender, EventArgs e)
        {
            
            if (haleemFav_button.BackColor == Color.White)
            {
                haleemFav_button.BackColor = Color.OrangeRed;
                obj.addFavorite("Haleem");
                L_5.Visible = true;
                timer1.Start();
            }
            else
            {
                haleemFav_button.BackColor = Color.White;
                obj.removeFavorite("Haleem");
            }
        }



        /////////// Timer For Add to fav/ add to cart labels///////
        private void timer1_Tick(object sender, EventArgs e)
        {
            if (flag_1.Visible || flag_2.Visible || flag_3.Visible || flag_4.Visible || flag_5.Visible)
            {
                flag_1.Visible = false;
                flag_2.Visible = false;
                flag_3.Visible = false;
                flag_4.Visible = false;
                flag_5.Visible = false;
                timer1.Stop();
            }

            if (L_1.Visible || L_2.Visible || L_3.Visible || L_4.Visible || L_5.Visible)
            {
                L_1.Visible = false;
                L_2.Visible = false;
                L_3.Visible = false;
                L_4.Visible = false;
                L_5.Visible = false;
                timer1.Stop();
            }
        }


    }



}

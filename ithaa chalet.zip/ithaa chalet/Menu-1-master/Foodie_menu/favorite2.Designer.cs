﻿namespace Foodie_menu
{
    partial class favorite2
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel2 = new System.Windows.Forms.Panel();
            this.flag = new System.Windows.Forms.Label();
            this.remove_button = new System.Windows.Forms.Button();
            this.cart_button = new System.Windows.Forms.Button();
            this.item_picture = new System.Windows.Forms.PictureBox();
            this.favList = new System.Windows.Forms.ListBox();
            this.bunifuElipse1 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.item_picture)).BeginInit();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Controls.Add(this.flag);
            this.panel2.Controls.Add(this.remove_button);
            this.panel2.Controls.Add(this.cart_button);
            this.panel2.Controls.Add(this.item_picture);
            this.panel2.Controls.Add(this.favList);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(941, 476);
            this.panel2.TabIndex = 1;
            // 
            // flag
            // 
            this.flag.AutoSize = true;
            this.flag.Font = new System.Drawing.Font("Microsoft JhengHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.flag.ForeColor = System.Drawing.Color.Red;
            this.flag.Location = new System.Drawing.Point(340, 383);
            this.flag.Name = "flag";
            this.flag.Size = new System.Drawing.Size(127, 20);
            this.flag.TabIndex = 4;
            this.flag.Text = "Added To Cart!";
            this.flag.Visible = false;
            // 
            // remove_button
            // 
            this.remove_button.FlatAppearance.BorderSize = 0;
            this.remove_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.remove_button.Font = new System.Drawing.Font("Microsoft JhengHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.remove_button.ForeColor = System.Drawing.Color.Gold;
            this.remove_button.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.remove_button.Location = new System.Drawing.Point(183, 419);
            this.remove_button.Name = "remove_button";
            this.remove_button.Size = new System.Drawing.Size(144, 38);
            this.remove_button.TabIndex = 3;
            this.remove_button.Text = "Remove";
            this.remove_button.UseVisualStyleBackColor = true;
            this.remove_button.Click += new System.EventHandler(this.remove_button_Click);
            // 
            // cart_button
            // 
            this.cart_button.BackColor = System.Drawing.Color.White;
            this.cart_button.FlatAppearance.BorderSize = 0;
            this.cart_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cart_button.Font = new System.Drawing.Font("Microsoft JhengHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cart_button.ForeColor = System.Drawing.Color.Gold;
            this.cart_button.Location = new System.Drawing.Point(333, 419);
            this.cart_button.Name = "cart_button";
            this.cart_button.Size = new System.Drawing.Size(144, 38);
            this.cart_button.TabIndex = 2;
            this.cart_button.Text = "Add To Cart";
            this.cart_button.UseVisualStyleBackColor = false;
            this.cart_button.Click += new System.EventHandler(this.cart_button_Click);
            // 
            // item_picture
            // 
            this.item_picture.Location = new System.Drawing.Point(0, 0);
            this.item_picture.Name = "item_picture";
            this.item_picture.Size = new System.Drawing.Size(493, 341);
            this.item_picture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.item_picture.TabIndex = 1;
            this.item_picture.TabStop = false;
            this.item_picture.Visible = false;
            // 
            // favList
            // 
            this.favList.BackColor = System.Drawing.Color.Gold;
            this.favList.Dock = System.Windows.Forms.DockStyle.Right;
            this.favList.Font = new System.Drawing.Font("Microsoft JhengHei UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.favList.ForeColor = System.Drawing.Color.Black;
            this.favList.FormattingEnabled = true;
            this.favList.ItemHeight = 24;
            this.favList.Location = new System.Drawing.Point(492, 0);
            this.favList.Name = "favList";
            this.favList.Size = new System.Drawing.Size(449, 476);
            this.favList.TabIndex = 0;
            this.favList.SelectedIndexChanged += new System.EventHandler(this.favList_SelectedIndexChanged);
            // 
            // bunifuElipse1
            // 
            this.bunifuElipse1.ElipseRadius = 50;
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // favorite2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.panel2);
            this.Margin = new System.Windows.Forms.Padding(0);
            this.Name = "favorite2";
            this.Size = new System.Drawing.Size(941, 476);
            this.Load += new System.EventHandler(this.favorite2_Load);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.item_picture)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label flag;
        private System.Windows.Forms.Button remove_button;
        private System.Windows.Forms.Button cart_button;
        private System.Windows.Forms.PictureBox item_picture;
        private System.Windows.Forms.ListBox favList;
        private Bunifu.Framework.UI.BunifuElipse bunifuElipse1;
        private System.Windows.Forms.Timer timer1;
    }
}

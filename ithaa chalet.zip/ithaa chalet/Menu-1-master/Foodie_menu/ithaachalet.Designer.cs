﻿namespace Foodie_menu
{
    partial class ithaachalet
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.minimize_button = new System.Windows.Forms.PictureBox();
            this.close_button = new System.Windows.Forms.PictureBox();
            this.cart_button = new System.Windows.Forms.PictureBox();
            this.slide_panel = new System.Windows.Forms.Panel();
            this.review_button = new System.Windows.Forms.Button();
            this.favorites_button = new System.Windows.Forms.Button();
            this.homeFood_button = new System.Windows.Forms.Button();
            this.exclusive_button = new System.Windows.Forms.Button();
            this.home_button = new System.Windows.Forms.Button();
            this.cart21 = new Foodie_menu.cart2();
            this.review21 = new Foodie_menu.review2();
            this.homeFood21 = new Foodie_menu.homeFood2();
            this.favorite21 = new Foodie_menu.favorite2();
            this.exclusive21 = new Foodie_menu.exclusive2();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.minimize_button)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.close_button)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cart_button)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Gold;
            this.panel1.Controls.Add(this.minimize_button);
            this.panel1.Controls.Add(this.close_button);
            this.panel1.Controls.Add(this.cart_button);
            this.panel1.Controls.Add(this.slide_panel);
            this.panel1.Controls.Add(this.review_button);
            this.panel1.Controls.Add(this.favorites_button);
            this.panel1.Controls.Add(this.homeFood_button);
            this.panel1.Controls.Add(this.exclusive_button);
            this.panel1.Controls.Add(this.home_button);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(943, 67);
            this.panel1.TabIndex = 1;
            // 
            // minimize_button
            // 
            this.minimize_button.BackColor = System.Drawing.Color.Gold;
            this.minimize_button.Image = global::Foodie_menu.Resource1.minimize;
            this.minimize_button.Location = new System.Drawing.Point(892, 0);
            this.minimize_button.Margin = new System.Windows.Forms.Padding(0);
            this.minimize_button.Name = "minimize_button";
            this.minimize_button.Size = new System.Drawing.Size(19, 19);
            this.minimize_button.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.minimize_button.TabIndex = 7;
            this.minimize_button.TabStop = false;
            this.minimize_button.Click += new System.EventHandler(this.minimize_button_Click);
            // 
            // close_button
            // 
            this.close_button.BackColor = System.Drawing.Color.Gold;
            this.close_button.Image = global::Foodie_menu.Resource1.close;
            this.close_button.Location = new System.Drawing.Point(922, 0);
            this.close_button.Margin = new System.Windows.Forms.Padding(0);
            this.close_button.Name = "close_button";
            this.close_button.Size = new System.Drawing.Size(19, 19);
            this.close_button.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.close_button.TabIndex = 7;
            this.close_button.TabStop = false;
            this.close_button.Click += new System.EventHandler(this.close_button_Click);
            // 
            // cart_button
            // 
            this.cart_button.Image = global::Foodie_menu.Resource1.cart1;
            this.cart_button.Location = new System.Drawing.Point(821, 24);
            this.cart_button.Name = "cart_button";
            this.cart_button.Size = new System.Drawing.Size(47, 43);
            this.cart_button.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.cart_button.TabIndex = 5;
            this.cart_button.TabStop = false;
            this.cart_button.Click += new System.EventHandler(this.cart_button_Click);
            // 
            // slide_panel
            // 
            this.slide_panel.BackColor = System.Drawing.Color.White;
            this.slide_panel.Location = new System.Drawing.Point(0, 0);
            this.slide_panel.Name = "slide_panel";
            this.slide_panel.Size = new System.Drawing.Size(124, 5);
            this.slide_panel.TabIndex = 1;
            // 
            // review_button
            // 
            this.review_button.BackColor = System.Drawing.Color.Gold;
            this.review_button.FlatAppearance.BorderColor = System.Drawing.Color.Gold;
            this.review_button.FlatAppearance.BorderSize = 0;
            this.review_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.review_button.Font = new System.Drawing.Font("Microsoft JhengHei UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.review_button.ForeColor = System.Drawing.Color.White;
            this.review_button.Image = global::Foodie_menu.Resource1.inspection;
            this.review_button.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.review_button.Location = new System.Drawing.Point(590, 18);
            this.review_button.Name = "review_button";
            this.review_button.Size = new System.Drawing.Size(144, 49);
            this.review_button.TabIndex = 4;
            this.review_button.Text = "Review";
            this.review_button.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.review_button.UseVisualStyleBackColor = false;
            this.review_button.Click += new System.EventHandler(this.review_button_Click);
            // 
            // favorites_button
            // 
            this.favorites_button.BackColor = System.Drawing.Color.Gold;
            this.favorites_button.FlatAppearance.BorderColor = System.Drawing.Color.Gold;
            this.favorites_button.FlatAppearance.BorderSize = 0;
            this.favorites_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.favorites_button.Font = new System.Drawing.Font("Microsoft JhengHei UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.favorites_button.ForeColor = System.Drawing.Color.White;
            this.favorites_button.Image = global::Foodie_menu.Resource1.star;
            this.favorites_button.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.favorites_button.Location = new System.Drawing.Point(440, 21);
            this.favorites_button.Name = "favorites_button";
            this.favorites_button.Size = new System.Drawing.Size(144, 46);
            this.favorites_button.TabIndex = 3;
            this.favorites_button.Text = "  Favorites";
            this.favorites_button.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.favorites_button.UseVisualStyleBackColor = false;
            this.favorites_button.Click += new System.EventHandler(this.favorites_button_Click);
            // 
            // homeFood_button
            // 
            this.homeFood_button.BackColor = System.Drawing.Color.Gold;
            this.homeFood_button.FlatAppearance.BorderColor = System.Drawing.Color.Gold;
            this.homeFood_button.FlatAppearance.BorderSize = 0;
            this.homeFood_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.homeFood_button.Font = new System.Drawing.Font("Microsoft JhengHei UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.homeFood_button.ForeColor = System.Drawing.Color.White;
            this.homeFood_button.Image = global::Foodie_menu.Resource1.special;
            this.homeFood_button.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.homeFood_button.Location = new System.Drawing.Point(286, 21);
            this.homeFood_button.Name = "homeFood_button";
            this.homeFood_button.Size = new System.Drawing.Size(148, 46);
            this.homeFood_button.TabIndex = 2;
            this.homeFood_button.Text = " Speciality";
            this.homeFood_button.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            this.homeFood_button.UseVisualStyleBackColor = false;
            this.homeFood_button.Click += new System.EventHandler(this.homeFood_button_Click);
            // 
            // exclusive_button
            // 
            this.exclusive_button.BackColor = System.Drawing.Color.Gold;
            this.exclusive_button.FlatAppearance.BorderColor = System.Drawing.Color.Gold;
            this.exclusive_button.FlatAppearance.BorderSize = 0;
            this.exclusive_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.exclusive_button.Font = new System.Drawing.Font("Microsoft JhengHei UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exclusive_button.ForeColor = System.Drawing.Color.White;
            this.exclusive_button.Image = global::Foodie_menu.Resource1.membership;
            this.exclusive_button.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.exclusive_button.Location = new System.Drawing.Point(130, 21);
            this.exclusive_button.Name = "exclusive_button";
            this.exclusive_button.Size = new System.Drawing.Size(150, 46);
            this.exclusive_button.TabIndex = 1;
            this.exclusive_button.Text = "      Exclusives";
            this.exclusive_button.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.exclusive_button.UseVisualStyleBackColor = false;
            this.exclusive_button.Click += new System.EventHandler(this.exclusive_button_Click);
            // 
            // home_button
            // 
            this.home_button.BackColor = System.Drawing.Color.Gold;
            this.home_button.FlatAppearance.BorderColor = System.Drawing.Color.Gold;
            this.home_button.FlatAppearance.BorderSize = 0;
            this.home_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.home_button.Font = new System.Drawing.Font("Microsoft JhengHei UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.home_button.ForeColor = System.Drawing.Color.White;
            this.home_button.Image = global::Foodie_menu.Resource1.homem2;
            this.home_button.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.home_button.Location = new System.Drawing.Point(0, 21);
            this.home_button.Name = "home_button";
            this.home_button.Size = new System.Drawing.Size(124, 46);
            this.home_button.TabIndex = 0;
            this.home_button.Text = "  Home";
            this.home_button.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.home_button.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.home_button.UseVisualStyleBackColor = false;
            this.home_button.Click += new System.EventHandler(this.home_button_Click);
            // 
            // cart21
            // 
            this.cart21.Location = new System.Drawing.Point(716, 67);
            this.cart21.Name = "cart21";
            this.cart21.Size = new System.Drawing.Size(227, 479);
            this.cart21.TabIndex = 9;
            // 
            // review21
            // 
            this.review21.BackColor = System.Drawing.Color.White;
            this.review21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.review21.Location = new System.Drawing.Point(0, 67);
            this.review21.Name = "review21";
            this.review21.Size = new System.Drawing.Size(943, 479);
            this.review21.TabIndex = 6;
            this.review21.Load += new System.EventHandler(this.review21_Load);
            // 
            // homeFood21
            // 
            this.homeFood21.AutoScroll = true;
            this.homeFood21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.homeFood21.Location = new System.Drawing.Point(0, 67);
            this.homeFood21.Name = "homeFood21";
            this.homeFood21.Size = new System.Drawing.Size(943, 479);
            this.homeFood21.TabIndex = 5;
            // 
            // favorite21
            // 
            this.favorite21.BackColor = System.Drawing.Color.White;
            this.favorite21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.favorite21.Location = new System.Drawing.Point(0, 67);
            this.favorite21.Margin = new System.Windows.Forms.Padding(0);
            this.favorite21.Name = "favorite21";
            this.favorite21.Size = new System.Drawing.Size(943, 479);
            this.favorite21.TabIndex = 4;
            // 
            // exclusive21
            // 
            this.exclusive21.AutoScroll = true;
            this.exclusive21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.exclusive21.Location = new System.Drawing.Point(0, 67);
            this.exclusive21.Name = "exclusive21";
            this.exclusive21.Size = new System.Drawing.Size(943, 479);
            this.exclusive21.TabIndex = 3;
            // 
            // ithaachalet
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(943, 546);
            this.Controls.Add(this.cart21);
            this.Controls.Add(this.review21);
            this.Controls.Add(this.homeFood21);
            this.Controls.Add(this.favorite21);
            this.Controls.Add(this.exclusive21);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "ithaachalet";
            this.ShowIcon = false;
            this.Text = "ithaachalet";
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.minimize_button)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.close_button)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cart_button)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
     
        private System.Windows.Forms.PictureBox minimize_button;
        private System.Windows.Forms.PictureBox close_button;
        private System.Windows.Forms.PictureBox cart_button;
        private System.Windows.Forms.Panel slide_panel;
        private System.Windows.Forms.Button review_button;
        private System.Windows.Forms.Button favorites_button;
        private System.Windows.Forms.Button homeFood_button;
        private System.Windows.Forms.Button exclusive_button;
        private System.Windows.Forms.Button home_button;
        private exclusive2 exclusive21;
        private favorite2 favorite21;
        private homeFood2 homeFood21;
        private review2 review21;
        private cart2 cart21;
    }
}
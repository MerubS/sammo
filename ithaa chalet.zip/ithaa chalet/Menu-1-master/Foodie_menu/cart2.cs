﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Foodie_menu
{
    public partial class cart2 : UserControl
    {
        myCart2 obj = new myCart2();
        public cart2()
        {
            InitializeComponent();
        }

        public void work()               // Displays Changes when Interface is displayed
        {
            item_list.Items.Clear();
            for(int i =0; i< myCart2.index1_2; i++)
            {
                item_list.Items.Add(myCart2.items_2[i]);
            }
            bill_label.Text = "Rs." + obj._bill.ToString();
        }

       

        private void checkout_button_Click(object sender, EventArgs e)     // Proceed to checkout option
        {
            if (obj._bill == 0)
            {
                MessageBox.Show("You Cant Leave with an empty cart!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }
        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void item_list_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)           // to remove items from cart
        {
            obj.removeItem(item_list.SelectedItem.ToString());
            item_list.Items.Remove(item_list.SelectedItem);
            bill_label.Text = "Rs." + obj._bill.ToString();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}

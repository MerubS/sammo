﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Foodie_menu
{
    public partial class ithaachalet : Form
    {
        public ithaachalet()
        {
            InitializeComponent();
            movePanel(exclusive_button);
            exclusive21.BringToFront();
        }
        private void ithaachalet_Load(object sender, EventArgs e)
        {
            myCart1 obj = new myCart1();
            obj.review_updater();
          
        }
        public void movePanel(Control btn)
        {
            slide_panel.Width = btn.Width;
            slide_panel.Left = btn.Left;

        }
        private void review21_Load(object sender, EventArgs e)
        {

        }

        private void home_button_Click(object sender, EventArgs e)
        {
            movePanel(home_button);
            this.Hide();
            restaurant sr = new restaurant();
            sr.Show();

        }

        private void exclusive_button_Click(object sender, EventArgs e)
        {
            movePanel(exclusive_button);
            exclusive21.BringToFront();
            exclusive21.work();
            


        }

        private void homeFood_button_Click(object sender, EventArgs e)
        {
            movePanel(homeFood_button);
            homeFood21.BringToFront();
            homeFood21.work();
        }

        private void favorites_button_Click(object sender, EventArgs e)
        {

            movePanel(favorites_button);
            favorite21.BringToFront();
            favorite21.work();
        }

        private void review_button_Click(object sender, EventArgs e)
        {
            movePanel(review_button);
            review21.BringToFront();
            review21.work();
        }

        private void cart_button_Click(object sender, EventArgs e)
        {
            cart21.BringToFront();
            cart21.work();
        }

        private void close_button_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void minimize_button_Click(object sender, EventArgs e)
        {
            if (this.WindowState != FormWindowState.Minimized)
                this.WindowState = FormWindowState.Minimized;
        }
    }
}

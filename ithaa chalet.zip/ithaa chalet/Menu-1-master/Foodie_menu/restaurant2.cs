﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Foodie_menu
{
    public partial class restaurant2 : UserControl
    {
       
        public restaurant2()
        {
            InitializeComponent();
        }

        private void restaurant2_Load(object sender, EventArgs e)
        {
            home21.BringToFront();
            
        }

        private void home2_button_Click(object sender, EventArgs e)
        {
            home21.BringToFront();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            myCart2 obj = new myCart2();
            obj.review_updater();
            exclusive21.BringToFront();
            exclusive21.work();

        }

        private void homeFood2_button_Click(object sender, EventArgs e)
        {
            myCart2 obj = new myCart2();
            obj.review_updater();

            homeFood21.BringToFront();
            homeFood21.work();
        }

        private void favorites2_button_Click(object sender, EventArgs e)
        {
            favorite21.BringToFront();
            favorite21.work();
        }

        private void review2_button_Click(object sender, EventArgs e)
        {
            review21.BringToFront();
            review21.work();
        }

        

        

       

        private void close_button_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void minimize_button_Click(object sender, EventArgs e)
        {
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            cart21.BringToFront();
            cart21.work();
        }
    }
}

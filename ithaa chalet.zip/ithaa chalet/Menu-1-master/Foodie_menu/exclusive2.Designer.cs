﻿namespace Foodie_menu
{
    partial class exclusive2
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(exclusive2));
            this.panel1 = new System.Windows.Forms.Panel();
            this.flag_1 = new System.Windows.Forms.Label();
            this.latteFav_button = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.latte_button = new System.Windows.Forms.Button();
            this.latte_rating = new Bunifu.Framework.UI.BunifuRating();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.flag_2 = new System.Windows.Forms.Label();
            this.capuccinoFav_button = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.capuccino_button = new System.Windows.Forms.Button();
            this.capuccino_rating = new Bunifu.Framework.UI.BunifuRating();
            this.label3 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.flag_3 = new System.Windows.Forms.Label();
            this.cortadoFav_button = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.cortado_button = new System.Windows.Forms.Button();
            this.cortado_rating = new Bunifu.Framework.UI.BunifuRating();
            this.label4 = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.flag_4 = new System.Windows.Forms.Label();
            this.mochaFav_button = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.mocha_button = new System.Windows.Forms.Button();
            this.mocha_rating = new Bunifu.Framework.UI.BunifuRating();
            this.label5 = new System.Windows.Forms.Label();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.panel6 = new System.Windows.Forms.Panel();
            this.flag_5 = new System.Windows.Forms.Label();
            this.americanoFav_button = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.americano_button = new System.Windows.Forms.Button();
            this.americano_rating = new Bunifu.Framework.UI.BunifuRating();
            this.label6 = new System.Windows.Forms.Label();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.flag_1);
            this.panel1.Controls.Add(this.latteFav_button);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.latte_button);
            this.panel1.Controls.Add(this.latte_rating);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(890, 181);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // flag_1
            // 
            this.flag_1.AutoSize = true;
            this.flag_1.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.flag_1.ForeColor = System.Drawing.Color.Indigo;
            this.flag_1.Location = new System.Drawing.Point(740, 121);
            this.flag_1.Name = "flag_1";
            this.flag_1.Size = new System.Drawing.Size(56, 23);
            this.flag_1.TabIndex = 7;
            this.flag_1.Text = "Flag 1";
            this.flag_1.Visible = false;
            // 
            // latteFav_button
            // 
            this.latteFav_button.BackColor = System.Drawing.Color.White;
            this.latteFav_button.FlatAppearance.BorderSize = 0;
            this.latteFav_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.latteFav_button.Image = ((System.Drawing.Image)(resources.GetObject("latteFav_button.Image")));
            this.latteFav_button.Location = new System.Drawing.Point(17, 3);
            this.latteFav_button.Name = "latteFav_button";
            this.latteFav_button.Size = new System.Drawing.Size(31, 30);
            this.latteFav_button.TabIndex = 5;
            this.latteFav_button.UseVisualStyleBackColor = false;
            this.latteFav_button.Click += new System.EventHandler(this.latte_favorite_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.White;
            this.label7.Font = new System.Drawing.Font("Microsoft JhengHei UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Gold;
            this.label7.Location = new System.Drawing.Point(761, 59);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(87, 30);
            this.label7.TabIndex = 4;
            this.label7.Text = "Rs.250";
            // 
            // latte_button
            // 
            this.latte_button.BackColor = System.Drawing.Color.White;
            this.latte_button.FlatAppearance.BorderSize = 0;
            this.latte_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.latte_button.Font = new System.Drawing.Font("Microsoft JhengHei UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.latte_button.ForeColor = System.Drawing.Color.Gold;
            this.latte_button.Location = new System.Drawing.Point(736, 16);
            this.latte_button.Name = "latte_button";
            this.latte_button.Size = new System.Drawing.Size(138, 37);
            this.latte_button.TabIndex = 3;
            this.latte_button.Text = "Add To Cart";
            this.latte_button.UseVisualStyleBackColor = false;
            this.latte_button.Click += new System.EventHandler(this.latte_button_Click);
            // 
            // latte_rating
            // 
            this.latte_rating.BackColor = System.Drawing.Color.Transparent;
            this.latte_rating.Enabled = false;
            this.latte_rating.ForeColor = System.Drawing.Color.Gold;
            this.latte_rating.Location = new System.Drawing.Point(392, 16);
            this.latte_rating.Margin = new System.Windows.Forms.Padding(2);
            this.latte_rating.Name = "latte_rating";
            this.latte_rating.Size = new System.Drawing.Size(164, 31);
            this.latte_rating.TabIndex = 2;
            this.latte_rating.Value = 0;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Verdana", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(295, 13);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(92, 32);
            this.label2.TabIndex = 1;
            this.label2.Text = "Latte";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Foodie_menu.Resource1.latte;
            this.pictureBox1.Location = new System.Drawing.Point(54, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(235, 181);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.White;
            this.panel3.Controls.Add(this.flag_2);
            this.panel3.Controls.Add(this.capuccinoFav_button);
            this.panel3.Controls.Add(this.label8);
            this.panel3.Controls.Add(this.capuccino_button);
            this.panel3.Controls.Add(this.capuccino_rating);
            this.panel3.Controls.Add(this.label3);
            this.panel3.Controls.Add(this.pictureBox2);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel3.Location = new System.Drawing.Point(0, 181);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(890, 181);
            this.panel3.TabIndex = 2;
            // 
            // flag_2
            // 
            this.flag_2.AutoSize = true;
            this.flag_2.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.flag_2.ForeColor = System.Drawing.Color.Indigo;
            this.flag_2.Location = new System.Drawing.Point(740, 127);
            this.flag_2.Name = "flag_2";
            this.flag_2.Size = new System.Drawing.Size(56, 23);
            this.flag_2.TabIndex = 8;
            this.flag_2.Text = "Flag 2";
            this.flag_2.Visible = false;
            this.flag_2.Click += new System.EventHandler(this.flag_2_Click);
            // 
            // capuccinoFav_button
            // 
            this.capuccinoFav_button.BackColor = System.Drawing.Color.White;
            this.capuccinoFav_button.FlatAppearance.BorderSize = 0;
            this.capuccinoFav_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.capuccinoFav_button.Image = ((System.Drawing.Image)(resources.GetObject("capuccinoFav_button.Image")));
            this.capuccinoFav_button.Location = new System.Drawing.Point(14, 0);
            this.capuccinoFav_button.Name = "capuccinoFav_button";
            this.capuccinoFav_button.Size = new System.Drawing.Size(31, 30);
            this.capuccinoFav_button.TabIndex = 6;
            this.capuccinoFav_button.UseVisualStyleBackColor = false;
            this.capuccinoFav_button.Click += new System.EventHandler(this.capuccinoFav_button_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.White;
            this.label8.Font = new System.Drawing.Font("Microsoft JhengHei UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Gold;
            this.label8.Location = new System.Drawing.Point(761, 63);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(87, 30);
            this.label8.TabIndex = 5;
            this.label8.Text = "Rs.300";
            // 
            // capuccino_button
            // 
            this.capuccino_button.BackColor = System.Drawing.Color.White;
            this.capuccino_button.FlatAppearance.BorderSize = 0;
            this.capuccino_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.capuccino_button.Font = new System.Drawing.Font("Microsoft JhengHei UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.capuccino_button.ForeColor = System.Drawing.Color.Gold;
            this.capuccino_button.Location = new System.Drawing.Point(736, 19);
            this.capuccino_button.Name = "capuccino_button";
            this.capuccino_button.Size = new System.Drawing.Size(138, 37);
            this.capuccino_button.TabIndex = 4;
            this.capuccino_button.Text = "Add To Cart";
            this.capuccino_button.UseVisualStyleBackColor = false;
            this.capuccino_button.Click += new System.EventHandler(this.capuccino_button_Click);
            // 
            // capuccino_rating
            // 
            this.capuccino_rating.BackColor = System.Drawing.Color.Transparent;
            this.capuccino_rating.Enabled = false;
            this.capuccino_rating.ForeColor = System.Drawing.Color.Gold;
            this.capuccino_rating.Location = new System.Drawing.Point(489, 19);
            this.capuccino_rating.Margin = new System.Windows.Forms.Padding(2);
            this.capuccino_rating.Name = "capuccino_rating";
            this.capuccino_rating.Size = new System.Drawing.Size(164, 31);
            this.capuccino_rating.TabIndex = 3;
            this.capuccino_rating.Value = 0;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Verdana", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(295, 16);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(189, 32);
            this.label3.TabIndex = 2;
            this.label3.Text = "Cappuccino";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::Foodie_menu.Resource1.cappucino;
            this.pictureBox2.Location = new System.Drawing.Point(54, 0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(235, 181);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.White;
            this.panel4.Controls.Add(this.flag_3);
            this.panel4.Controls.Add(this.cortadoFav_button);
            this.panel4.Controls.Add(this.label9);
            this.panel4.Controls.Add(this.cortado_button);
            this.panel4.Controls.Add(this.cortado_rating);
            this.panel4.Controls.Add(this.label4);
            this.panel4.Controls.Add(this.pictureBox3);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel4.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel4.Location = new System.Drawing.Point(0, 362);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(890, 181);
            this.panel4.TabIndex = 3;
            // 
            // flag_3
            // 
            this.flag_3.AutoSize = true;
            this.flag_3.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.flag_3.ForeColor = System.Drawing.Color.Indigo;
            this.flag_3.Location = new System.Drawing.Point(740, 125);
            this.flag_3.Name = "flag_3";
            this.flag_3.Size = new System.Drawing.Size(56, 23);
            this.flag_3.TabIndex = 8;
            this.flag_3.Text = "Flag 3";
            this.flag_3.Visible = false;
            // 
            // cortadoFav_button
            // 
            this.cortadoFav_button.BackColor = System.Drawing.Color.White;
            this.cortadoFav_button.FlatAppearance.BorderSize = 0;
            this.cortadoFav_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cortadoFav_button.Image = ((System.Drawing.Image)(resources.GetObject("cortadoFav_button.Image")));
            this.cortadoFav_button.Location = new System.Drawing.Point(14, 3);
            this.cortadoFav_button.Name = "cortadoFav_button";
            this.cortadoFav_button.Size = new System.Drawing.Size(31, 30);
            this.cortadoFav_button.TabIndex = 6;
            this.cortadoFav_button.UseVisualStyleBackColor = false;
            this.cortadoFav_button.Click += new System.EventHandler(this.cortadoFav_button_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.White;
            this.label9.Font = new System.Drawing.Font("Microsoft JhengHei UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Gold;
            this.label9.Location = new System.Drawing.Point(761, 55);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(87, 30);
            this.label9.TabIndex = 5;
            this.label9.Text = "Rs.200";
            // 
            // cortado_button
            // 
            this.cortado_button.BackColor = System.Drawing.Color.White;
            this.cortado_button.FlatAppearance.BorderSize = 0;
            this.cortado_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cortado_button.Font = new System.Drawing.Font("Microsoft JhengHei UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cortado_button.ForeColor = System.Drawing.Color.Gold;
            this.cortado_button.Location = new System.Drawing.Point(736, 15);
            this.cortado_button.Name = "cortado_button";
            this.cortado_button.Size = new System.Drawing.Size(138, 37);
            this.cortado_button.TabIndex = 4;
            this.cortado_button.Text = "Add To Cart";
            this.cortado_button.UseVisualStyleBackColor = false;
            this.cortado_button.Click += new System.EventHandler(this.cortado_button_Click);
            // 
            // cortado_rating
            // 
            this.cortado_rating.BackColor = System.Drawing.Color.Transparent;
            this.cortado_rating.Enabled = false;
            this.cortado_rating.ForeColor = System.Drawing.Color.Gold;
            this.cortado_rating.Location = new System.Drawing.Point(435, 21);
            this.cortado_rating.Margin = new System.Windows.Forms.Padding(2);
            this.cortado_rating.Name = "cortado_rating";
            this.cortado_rating.Size = new System.Drawing.Size(164, 31);
            this.cortado_rating.TabIndex = 3;
            this.cortado_rating.Value = 0;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Verdana", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(295, 18);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(135, 32);
            this.label4.TabIndex = 2;
            this.label4.Text = "Cortado";
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::Foodie_menu.Resource1.cortado;
            this.pictureBox3.Location = new System.Drawing.Point(54, 0);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(235, 181);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 1;
            this.pictureBox3.TabStop = false;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.White;
            this.panel5.Controls.Add(this.flag_4);
            this.panel5.Controls.Add(this.mochaFav_button);
            this.panel5.Controls.Add(this.label10);
            this.panel5.Controls.Add(this.mocha_button);
            this.panel5.Controls.Add(this.mocha_rating);
            this.panel5.Controls.Add(this.label5);
            this.panel5.Controls.Add(this.pictureBox4);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel5.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel5.Location = new System.Drawing.Point(0, 543);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(890, 181);
            this.panel5.TabIndex = 4;
            // 
            // flag_4
            // 
            this.flag_4.AutoSize = true;
            this.flag_4.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.flag_4.ForeColor = System.Drawing.Color.Indigo;
            this.flag_4.Location = new System.Drawing.Point(740, 118);
            this.flag_4.Name = "flag_4";
            this.flag_4.Size = new System.Drawing.Size(56, 23);
            this.flag_4.TabIndex = 8;
            this.flag_4.Text = "Flag 4";
            this.flag_4.Visible = false;
            // 
            // mochaFav_button
            // 
            this.mochaFav_button.BackColor = System.Drawing.Color.White;
            this.mochaFav_button.FlatAppearance.BorderSize = 0;
            this.mochaFav_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.mochaFav_button.Image = ((System.Drawing.Image)(resources.GetObject("mochaFav_button.Image")));
            this.mochaFav_button.Location = new System.Drawing.Point(14, 3);
            this.mochaFav_button.Name = "mochaFav_button";
            this.mochaFav_button.Size = new System.Drawing.Size(31, 30);
            this.mochaFav_button.TabIndex = 6;
            this.mochaFav_button.UseVisualStyleBackColor = false;
            this.mochaFav_button.Click += new System.EventHandler(this.mochaFav_button_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.White;
            this.label10.Font = new System.Drawing.Font("Microsoft JhengHei UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Gold;
            this.label10.Location = new System.Drawing.Point(761, 60);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(87, 30);
            this.label10.TabIndex = 5;
            this.label10.Text = "Rs.350";
            // 
            // mocha_button
            // 
            this.mocha_button.BackColor = System.Drawing.Color.White;
            this.mocha_button.FlatAppearance.BorderSize = 0;
            this.mocha_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.mocha_button.Font = new System.Drawing.Font("Microsoft JhengHei UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mocha_button.ForeColor = System.Drawing.Color.Gold;
            this.mocha_button.Location = new System.Drawing.Point(736, 18);
            this.mocha_button.Name = "mocha_button";
            this.mocha_button.Size = new System.Drawing.Size(138, 37);
            this.mocha_button.TabIndex = 4;
            this.mocha_button.Text = "Add To Cart";
            this.mocha_button.UseVisualStyleBackColor = false;
            this.mocha_button.Click += new System.EventHandler(this.mocha_button_Click);
            // 
            // mocha_rating
            // 
            this.mocha_rating.BackColor = System.Drawing.Color.Transparent;
            this.mocha_rating.Enabled = false;
            this.mocha_rating.ForeColor = System.Drawing.Color.Gold;
            this.mocha_rating.Location = new System.Drawing.Point(413, 19);
            this.mocha_rating.Margin = new System.Windows.Forms.Padding(2);
            this.mocha_rating.Name = "mocha_rating";
            this.mocha_rating.Size = new System.Drawing.Size(164, 31);
            this.mocha_rating.TabIndex = 3;
            this.mocha_rating.Value = 0;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Verdana", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(295, 16);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(113, 32);
            this.label5.TabIndex = 2;
            this.label5.Text = "Mocha";
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::Foodie_menu.Resource1.mocha;
            this.pictureBox4.Location = new System.Drawing.Point(51, 0);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(235, 181);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 1;
            this.pictureBox4.TabStop = false;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.White;
            this.panel6.Controls.Add(this.flag_5);
            this.panel6.Controls.Add(this.americanoFav_button);
            this.panel6.Controls.Add(this.label11);
            this.panel6.Controls.Add(this.americano_button);
            this.panel6.Controls.Add(this.americano_rating);
            this.panel6.Controls.Add(this.label6);
            this.panel6.Controls.Add(this.pictureBox5);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel6.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel6.Location = new System.Drawing.Point(0, 724);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(890, 191);
            this.panel6.TabIndex = 5;
            this.panel6.Paint += new System.Windows.Forms.PaintEventHandler(this.panel6_Paint);
            // 
            // flag_5
            // 
            this.flag_5.AutoSize = true;
            this.flag_5.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.flag_5.ForeColor = System.Drawing.Color.Indigo;
            this.flag_5.Location = new System.Drawing.Point(740, 133);
            this.flag_5.Name = "flag_5";
            this.flag_5.Size = new System.Drawing.Size(56, 23);
            this.flag_5.TabIndex = 8;
            this.flag_5.Text = "Flag 5";
            this.flag_5.Visible = false;
            // 
            // americanoFav_button
            // 
            this.americanoFav_button.BackColor = System.Drawing.Color.White;
            this.americanoFav_button.FlatAppearance.BorderSize = 0;
            this.americanoFav_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.americanoFav_button.Image = ((System.Drawing.Image)(resources.GetObject("americanoFav_button.Image")));
            this.americanoFav_button.Location = new System.Drawing.Point(14, 3);
            this.americanoFav_button.Name = "americanoFav_button";
            this.americanoFav_button.Size = new System.Drawing.Size(31, 30);
            this.americanoFav_button.TabIndex = 6;
            this.americanoFav_button.UseVisualStyleBackColor = false;
            this.americanoFav_button.Click += new System.EventHandler(this.americanoFav_button_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.White;
            this.label11.Font = new System.Drawing.Font("Microsoft JhengHei UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Gold;
            this.label11.Location = new System.Drawing.Point(761, 58);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(87, 30);
            this.label11.TabIndex = 5;
            this.label11.Text = "Rs.300";
            // 
            // americano_button
            // 
            this.americano_button.BackColor = System.Drawing.Color.White;
            this.americano_button.FlatAppearance.BorderSize = 0;
            this.americano_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.americano_button.Font = new System.Drawing.Font("Microsoft JhengHei UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.americano_button.ForeColor = System.Drawing.Color.Gold;
            this.americano_button.Location = new System.Drawing.Point(736, 17);
            this.americano_button.Name = "americano_button";
            this.americano_button.Size = new System.Drawing.Size(138, 37);
            this.americano_button.TabIndex = 4;
            this.americano_button.Text = "Add To Cart";
            this.americano_button.UseVisualStyleBackColor = false;
            this.americano_button.Click += new System.EventHandler(this.americano_button_Click);
            // 
            // americano_rating
            // 
            this.americano_rating.BackColor = System.Drawing.Color.Transparent;
            this.americano_rating.Enabled = false;
            this.americano_rating.ForeColor = System.Drawing.Color.Gold;
            this.americano_rating.Location = new System.Drawing.Point(477, 17);
            this.americano_rating.Margin = new System.Windows.Forms.Padding(2);
            this.americano_rating.Name = "americano_rating";
            this.americano_rating.Size = new System.Drawing.Size(164, 31);
            this.americano_rating.TabIndex = 3;
            this.americano_rating.Value = 0;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Verdana", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(295, 14);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(177, 32);
            this.label6.TabIndex = 2;
            this.label6.Text = "Americano";
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::Foodie_menu.Resource1.americano;
            this.pictureBox5.Location = new System.Drawing.Point(51, 0);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(235, 181);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 1;
            this.pictureBox5.TabStop = false;
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // exclusive2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.Name = "exclusive2";
            this.Size = new System.Drawing.Size(890, 476);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button latte_button;
        private Bunifu.Framework.UI.BunifuRating latte_rating;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button capuccino_button;
        private Bunifu.Framework.UI.BunifuRating capuccino_rating;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button cortado_button;
        private Bunifu.Framework.UI.BunifuRating cortado_rating;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button mocha_button;
        private Bunifu.Framework.UI.BunifuRating mocha_rating;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button americano_button;
        private Bunifu.Framework.UI.BunifuRating americano_rating;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label flag_1;
        private System.Windows.Forms.Button latteFav_button;
        private System.Windows.Forms.Label flag_2;
        private System.Windows.Forms.Button capuccinoFav_button;
        private System.Windows.Forms.Label flag_3;
        private System.Windows.Forms.Button cortadoFav_button;
        private System.Windows.Forms.Label flag_4;
        private System.Windows.Forms.Button mochaFav_button;
        private System.Windows.Forms.Label flag_5;
        private System.Windows.Forms.Button americanoFav_button;
        private System.Windows.Forms.Timer timer1;
    }
}

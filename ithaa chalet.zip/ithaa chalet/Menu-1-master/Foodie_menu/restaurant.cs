﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Foodie_menu
{
    public partial class restaurant : Form
    {
        public restaurant()
        {
            InitializeComponent();
        }

        private void sr1_Load(object sender, EventArgs e)
        {

        }

        private void ithaaChalet_button_Click(object sender, EventArgs e)
        {
            this.Hide();
            ithaachalet ic = new ithaachalet();
            ic.Show();
        }

        private void close_button_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void foodieHub_button_Click(object sender, EventArgs e)
        {
            Foodie_menu.FH open = new Foodie_menu.FH();
            open.Show();
            this.Hide();
        }
    }
}

﻿namespace Foodie_menu
{
    partial class cart1
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bill_label = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.item_list = new System.Windows.Forms.ListBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.remove_button = new System.Windows.Forms.Button();
            this.checkout_button = new System.Windows.Forms.Button();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // bill_label
            // 
            this.bill_label.AutoSize = true;
            this.bill_label.Font = new System.Drawing.Font("Microsoft JhengHei UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bill_label.ForeColor = System.Drawing.Color.Gold;
            this.bill_label.Location = new System.Drawing.Point(109, 329);
            this.bill_label.Name = "bill_label";
            this.bill_label.Size = new System.Drawing.Size(48, 24);
            this.bill_label.TabIndex = 4;
            this.bill_label.Text = "Rs.4";
            this.bill_label.Click += new System.EventHandler(this.bill_label_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft JhengHei UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Gold;
            this.label3.Location = new System.Drawing.Point(14, 327);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(64, 26);
            this.label3.TabIndex = 3;
            this.label3.Text = "Total";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // item_list
            // 
            this.item_list.BackColor = System.Drawing.Color.White;
            this.item_list.Font = new System.Drawing.Font("Microsoft JhengHei", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.item_list.FormattingEnabled = true;
            this.item_list.ItemHeight = 19;
            this.item_list.Location = new System.Drawing.Point(0, 149);
            this.item_list.Name = "item_list";
            this.item_list.Size = new System.Drawing.Size(270, 175);
            this.item_list.TabIndex = 2;
            this.item_list.SelectedIndexChanged += new System.EventHandler(this.item_list_SelectedIndexChanged);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Gold;
            this.panel2.Controls.Add(this.label4);
            this.panel2.Location = new System.Drawing.Point(0, 69);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(270, 63);
            this.panel2.TabIndex = 1;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft JhengHei UI", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(11, 13);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(182, 37);
            this.label4.TabIndex = 2;
            this.label4.Text = "Foodie Hub";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.White;
            this.label1.Font = new System.Drawing.Font("Microsoft JhengHei UI", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Gold;
            this.label1.Location = new System.Drawing.Point(12, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(158, 37);
            this.label1.TabIndex = 0;
            this.label1.Text = "My Order ";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // remove_button
            // 
            this.remove_button.BackColor = System.Drawing.Color.Gold;
            this.remove_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.remove_button.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.remove_button.ForeColor = System.Drawing.Color.White;
            this.remove_button.Image = global::Foodie_menu.Resource1.cross1;
            this.remove_button.Location = new System.Drawing.Point(136, 382);
            this.remove_button.Name = "remove_button";
            this.remove_button.Size = new System.Drawing.Size(134, 40);
            this.remove_button.TabIndex = 1;
            this.remove_button.Text = "Remove";
            this.remove_button.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.remove_button.UseVisualStyleBackColor = false;
            this.remove_button.Click += new System.EventHandler(this.remove_button_Click);
            // 
            // checkout_button
            // 
            this.checkout_button.BackColor = System.Drawing.Color.Gold;
            this.checkout_button.FlatAppearance.BorderSize = 0;
            this.checkout_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.checkout_button.Font = new System.Drawing.Font("Microsoft JhengHei UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkout_button.ForeColor = System.Drawing.Color.White;
            this.checkout_button.Image = global::Foodie_menu.Resource1.arrow1;
            this.checkout_button.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.checkout_button.Location = new System.Drawing.Point(136, 425);
            this.checkout_button.Margin = new System.Windows.Forms.Padding(3, 0, 3, 3);
            this.checkout_button.Name = "checkout_button";
            this.checkout_button.Size = new System.Drawing.Size(134, 38);
            this.checkout_button.TabIndex = 1;
            this.checkout_button.Text = "   Checkout";
            this.checkout_button.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.checkout_button.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.checkout_button.UseVisualStyleBackColor = false;
            this.checkout_button.Click += new System.EventHandler(this.checkout_button_Click);
            // 
            // cart1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.remove_button);
            this.Controls.Add(this.checkout_button);
            this.Controls.Add(this.bill_label);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.item_list);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel2);
            this.Name = "cart1";
            this.Size = new System.Drawing.Size(270, 466);
            this.Load += new System.EventHandler(this.cart1_Load);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button checkout_button;
        private System.Windows.Forms.ListBox item_list;
        private System.Windows.Forms.Label bill_label;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button remove_button;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label1;
    }
}

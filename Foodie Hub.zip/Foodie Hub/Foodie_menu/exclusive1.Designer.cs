﻿namespace Foodie_menu
{
    partial class exclusive1
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(exclusive1));
            this.panel1 = new System.Windows.Forms.Panel();
            this.pizza_Rating = new Bunifu.Framework.UI.BunifuRating();
            this.L_1 = new System.Windows.Forms.Label();
            this.flag_1 = new System.Windows.Forms.Label();
            this.pizza_button = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.burger_Rating = new Bunifu.Framework.UI.BunifuRating();
            this.L_4 = new System.Windows.Forms.Label();
            this.flag_4 = new System.Windows.Forms.Label();
            this.burger_button = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.sandwhich_Rating = new Bunifu.Framework.UI.BunifuRating();
            this.L_3 = new System.Windows.Forms.Label();
            this.flag_3 = new System.Windows.Forms.Label();
            this.sandwhich_button = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.pasta_Rating = new Bunifu.Framework.UI.BunifuRating();
            this.L_2 = new System.Windows.Forms.Label();
            this.flag_2 = new System.Windows.Forms.Label();
            this.pasta_button = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.fries_Rating = new Bunifu.Framework.UI.BunifuRating();
            this.L_5 = new System.Windows.Forms.Label();
            this.flag_5 = new System.Windows.Forms.Label();
            this.fries_button = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.friesFav_button = new System.Windows.Forms.Button();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pastaFav_button = new System.Windows.Forms.Button();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.sandwhichFav_button = new System.Windows.Forms.Button();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.burgerFav_button = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pizzaFav_button = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.pizza_Rating);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.L_1);
            this.panel1.Controls.Add(this.flag_1);
            this.panel1.Controls.Add(this.pizzaFav_button);
            this.panel1.Controls.Add(this.pizza_button);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.ForeColor = System.Drawing.Color.Gold;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(856, 203);
            this.panel1.TabIndex = 2;
            // 
            // pizza_Rating
            // 
            this.pizza_Rating.BackColor = System.Drawing.Color.Transparent;
            this.pizza_Rating.Enabled = false;
            this.pizza_Rating.ForeColor = System.Drawing.Color.Yellow;
            this.pizza_Rating.Location = new System.Drawing.Point(366, 24);
            this.pizza_Rating.Name = "pizza_Rating";
            this.pizza_Rating.Size = new System.Drawing.Size(184, 30);
            this.pizza_Rating.TabIndex = 8;
            this.pizza_Rating.Value = 0;
            // 
            // L_1
            // 
            this.L_1.AutoSize = true;
            this.L_1.Font = new System.Drawing.Font("Microsoft JhengHei UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.L_1.ForeColor = System.Drawing.Color.Red;
            this.L_1.Location = new System.Drawing.Point(702, 138);
            this.L_1.Name = "L_1";
            this.L_1.Size = new System.Drawing.Size(131, 15);
            this.L_1.TabIndex = 7;
            this.L_1.Text = " Added To Favorites!";
            this.L_1.Visible = false;
            // 
            // flag_1
            // 
            this.flag_1.AutoSize = true;
            this.flag_1.Font = new System.Drawing.Font("Microsoft JhengHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.flag_1.ForeColor = System.Drawing.Color.Red;
            this.flag_1.Location = new System.Drawing.Point(688, 108);
            this.flag_1.Name = "flag_1";
            this.flag_1.Size = new System.Drawing.Size(166, 20);
            this.flag_1.TabIndex = 6;
            this.flag_1.Text = "Item Added To Cart!";
            this.flag_1.Visible = false;
            // 
            // pizza_button
            // 
            this.pizza_button.BackColor = System.Drawing.Color.White;
            this.pizza_button.FlatAppearance.BorderSize = 0;
            this.pizza_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.pizza_button.Font = new System.Drawing.Font("Microsoft JhengHei UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pizza_button.Location = new System.Drawing.Point(705, 24);
            this.pizza_button.Name = "pizza_button";
            this.pizza_button.Size = new System.Drawing.Size(134, 30);
            this.pizza_button.TabIndex = 4;
            this.pizza_button.Text = "Add To Cart";
            this.pizza_button.UseVisualStyleBackColor = false;
            this.pizza_button.Click += new System.EventHandler(this.pizza_button_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.White;
            this.label7.Font = new System.Drawing.Font("Microsoft JhengHei UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Gold;
            this.label7.Location = new System.Drawing.Point(723, 57);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(98, 26);
            this.label7.TabIndex = 3;
            this.label7.Text = "Rs. 1500";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft JhengHei UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Gold;
            this.label2.Location = new System.Drawing.Point(271, 20);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(80, 35);
            this.label2.TabIndex = 2;
            this.label2.Text = "Pizza";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Controls.Add(this.burger_Rating);
            this.panel2.Controls.Add(this.L_4);
            this.panel2.Controls.Add(this.flag_4);
            this.panel2.Controls.Add(this.burgerFav_button);
            this.panel2.Controls.Add(this.burger_button);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.pictureBox2);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.ForeColor = System.Drawing.Color.Gold;
            this.panel2.Location = new System.Drawing.Point(0, 203);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(856, 203);
            this.panel2.TabIndex = 3;
            // 
            // burger_Rating
            // 
            this.burger_Rating.BackColor = System.Drawing.Color.Transparent;
            this.burger_Rating.Enabled = false;
            this.burger_Rating.ForeColor = System.Drawing.Color.Yellow;
            this.burger_Rating.Location = new System.Drawing.Point(380, 28);
            this.burger_Rating.Name = "burger_Rating";
            this.burger_Rating.Size = new System.Drawing.Size(184, 30);
            this.burger_Rating.TabIndex = 13;
            this.burger_Rating.Value = 0;
            // 
            // L_4
            // 
            this.L_4.AutoSize = true;
            this.L_4.Font = new System.Drawing.Font("Microsoft JhengHei UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.L_4.ForeColor = System.Drawing.Color.Red;
            this.L_4.Location = new System.Drawing.Point(702, 132);
            this.L_4.Name = "L_4";
            this.L_4.Size = new System.Drawing.Size(131, 15);
            this.L_4.TabIndex = 12;
            this.L_4.Text = " Added To Favorites!";
            this.L_4.Visible = false;
            // 
            // flag_4
            // 
            this.flag_4.AutoSize = true;
            this.flag_4.Font = new System.Drawing.Font("Microsoft JhengHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.flag_4.ForeColor = System.Drawing.Color.Red;
            this.flag_4.Location = new System.Drawing.Point(688, 103);
            this.flag_4.Name = "flag_4";
            this.flag_4.Size = new System.Drawing.Size(166, 20);
            this.flag_4.TabIndex = 11;
            this.flag_4.Text = "Item Added To Cart!";
            this.flag_4.Visible = false;
            // 
            // burger_button
            // 
            this.burger_button.BackColor = System.Drawing.Color.White;
            this.burger_button.FlatAppearance.BorderSize = 0;
            this.burger_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.burger_button.Font = new System.Drawing.Font("Microsoft JhengHei UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.burger_button.ForeColor = System.Drawing.Color.Gold;
            this.burger_button.Location = new System.Drawing.Point(705, 28);
            this.burger_button.Name = "burger_button";
            this.burger_button.Size = new System.Drawing.Size(134, 30);
            this.burger_button.TabIndex = 8;
            this.burger_button.Text = "Add To Cart";
            this.burger_button.UseVisualStyleBackColor = false;
            this.burger_button.Click += new System.EventHandler(this.burger_button_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.White;
            this.label8.Font = new System.Drawing.Font("Microsoft JhengHei UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Gold;
            this.label8.Location = new System.Drawing.Point(723, 61);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(98, 26);
            this.label8.TabIndex = 7;
            this.label8.Text = "Rs. 1000";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft JhengHei UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Gold;
            this.label3.Location = new System.Drawing.Point(271, 28);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(103, 35);
            this.label3.TabIndex = 6;
            this.label3.Text = "Burger";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.White;
            this.panel3.Controls.Add(this.sandwhich_Rating);
            this.panel3.Controls.Add(this.L_3);
            this.panel3.Controls.Add(this.flag_3);
            this.panel3.Controls.Add(this.sandwhichFav_button);
            this.panel3.Controls.Add(this.sandwhich_button);
            this.panel3.Controls.Add(this.label10);
            this.panel3.Controls.Add(this.label6);
            this.panel3.Controls.Add(this.pictureBox3);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.ForeColor = System.Drawing.Color.Gold;
            this.panel3.Location = new System.Drawing.Point(0, 406);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(856, 203);
            this.panel3.TabIndex = 3;
            // 
            // sandwhich_Rating
            // 
            this.sandwhich_Rating.BackColor = System.Drawing.Color.Transparent;
            this.sandwhich_Rating.Enabled = false;
            this.sandwhich_Rating.ForeColor = System.Drawing.Color.Yellow;
            this.sandwhich_Rating.Location = new System.Drawing.Point(434, 32);
            this.sandwhich_Rating.Name = "sandwhich_Rating";
            this.sandwhich_Rating.Size = new System.Drawing.Size(174, 30);
            this.sandwhich_Rating.TabIndex = 12;
            this.sandwhich_Rating.Value = 0;
            // 
            // L_3
            // 
            this.L_3.AutoSize = true;
            this.L_3.Font = new System.Drawing.Font("Microsoft JhengHei UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.L_3.ForeColor = System.Drawing.Color.Red;
            this.L_3.Location = new System.Drawing.Point(702, 144);
            this.L_3.Name = "L_3";
            this.L_3.Size = new System.Drawing.Size(131, 15);
            this.L_3.TabIndex = 11;
            this.L_3.Text = " Added To Favorites!";
            this.L_3.Visible = false;
            // 
            // flag_3
            // 
            this.flag_3.AutoSize = true;
            this.flag_3.Font = new System.Drawing.Font("Microsoft JhengHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.flag_3.ForeColor = System.Drawing.Color.Red;
            this.flag_3.Location = new System.Drawing.Point(688, 115);
            this.flag_3.Name = "flag_3";
            this.flag_3.Size = new System.Drawing.Size(166, 20);
            this.flag_3.TabIndex = 10;
            this.flag_3.Text = "Item Added To Cart!";
            this.flag_3.Visible = false;
            // 
            // sandwhich_button
            // 
            this.sandwhich_button.BackColor = System.Drawing.Color.White;
            this.sandwhich_button.FlatAppearance.BorderSize = 0;
            this.sandwhich_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.sandwhich_button.Font = new System.Drawing.Font("Microsoft JhengHei UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sandwhich_button.ForeColor = System.Drawing.Color.Gold;
            this.sandwhich_button.Location = new System.Drawing.Point(705, 31);
            this.sandwhich_button.Name = "sandwhich_button";
            this.sandwhich_button.Size = new System.Drawing.Size(134, 30);
            this.sandwhich_button.TabIndex = 7;
            this.sandwhich_button.Text = "Add To Cart";
            this.sandwhich_button.UseVisualStyleBackColor = false;
            this.sandwhich_button.Click += new System.EventHandler(this.sandwhich_button_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.White;
            this.label10.Font = new System.Drawing.Font("Microsoft JhengHei UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Gold;
            this.label10.Location = new System.Drawing.Point(736, 64);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(85, 26);
            this.label10.TabIndex = 7;
            this.label10.Text = "Rs. 300";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft JhengHei UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Gold;
            this.label6.Location = new System.Drawing.Point(271, 27);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(157, 35);
            this.label6.TabIndex = 6;
            this.label6.Text = "Sandwhich";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.White;
            this.panel4.Controls.Add(this.pasta_Rating);
            this.panel4.Controls.Add(this.L_2);
            this.panel4.Controls.Add(this.flag_2);
            this.panel4.Controls.Add(this.pastaFav_button);
            this.panel4.Controls.Add(this.pasta_button);
            this.panel4.Controls.Add(this.label9);
            this.panel4.Controls.Add(this.label4);
            this.panel4.Controls.Add(this.pictureBox4);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel4.ForeColor = System.Drawing.Color.Gold;
            this.panel4.Location = new System.Drawing.Point(0, 609);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(856, 203);
            this.panel4.TabIndex = 3;
            // 
            // pasta_Rating
            // 
            this.pasta_Rating.BackColor = System.Drawing.Color.Transparent;
            this.pasta_Rating.Enabled = false;
            this.pasta_Rating.ForeColor = System.Drawing.Color.Yellow;
            this.pasta_Rating.Location = new System.Drawing.Point(366, 30);
            this.pasta_Rating.Name = "pasta_Rating";
            this.pasta_Rating.Size = new System.Drawing.Size(181, 30);
            this.pasta_Rating.TabIndex = 11;
            this.pasta_Rating.Value = 0;
            // 
            // L_2
            // 
            this.L_2.AutoSize = true;
            this.L_2.Font = new System.Drawing.Font("Microsoft JhengHei UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.L_2.ForeColor = System.Drawing.Color.Red;
            this.L_2.Location = new System.Drawing.Point(702, 144);
            this.L_2.Name = "L_2";
            this.L_2.Size = new System.Drawing.Size(131, 15);
            this.L_2.TabIndex = 10;
            this.L_2.Text = " Added To Favorites!";
            this.L_2.Visible = false;
            // 
            // flag_2
            // 
            this.flag_2.AutoSize = true;
            this.flag_2.Font = new System.Drawing.Font("Microsoft JhengHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.flag_2.ForeColor = System.Drawing.Color.Red;
            this.flag_2.Location = new System.Drawing.Point(691, 115);
            this.flag_2.Name = "flag_2";
            this.flag_2.Size = new System.Drawing.Size(166, 20);
            this.flag_2.TabIndex = 9;
            this.flag_2.Text = "Item Added To Cart!";
            this.flag_2.Visible = false;
            // 
            // pasta_button
            // 
            this.pasta_button.BackColor = System.Drawing.Color.White;
            this.pasta_button.FlatAppearance.BorderSize = 0;
            this.pasta_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.pasta_button.Font = new System.Drawing.Font("Microsoft JhengHei UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pasta_button.ForeColor = System.Drawing.Color.Gold;
            this.pasta_button.Location = new System.Drawing.Point(705, 20);
            this.pasta_button.Name = "pasta_button";
            this.pasta_button.Size = new System.Drawing.Size(134, 30);
            this.pasta_button.TabIndex = 7;
            this.pasta_button.Text = "Add To Cart";
            this.pasta_button.UseVisualStyleBackColor = false;
            this.pasta_button.Click += new System.EventHandler(this.pasta_button_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.White;
            this.label9.Font = new System.Drawing.Font("Microsoft JhengHei UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Gold;
            this.label9.Location = new System.Drawing.Point(736, 53);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(85, 26);
            this.label9.TabIndex = 4;
            this.label9.Text = "Rs. 600";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft JhengHei UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Gold;
            this.label4.Location = new System.Drawing.Point(271, 25);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(85, 35);
            this.label4.TabIndex = 3;
            this.label4.Text = "Pasta";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.White;
            this.panel5.Controls.Add(this.fries_Rating);
            this.panel5.Controls.Add(this.L_5);
            this.panel5.Controls.Add(this.flag_5);
            this.panel5.Controls.Add(this.friesFav_button);
            this.panel5.Controls.Add(this.fries_button);
            this.panel5.Controls.Add(this.label11);
            this.panel5.Controls.Add(this.label5);
            this.panel5.Controls.Add(this.pictureBox5);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel5.ForeColor = System.Drawing.Color.Gold;
            this.panel5.Location = new System.Drawing.Point(0, 812);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(856, 203);
            this.panel5.TabIndex = 4;
            // 
            // fries_Rating
            // 
            this.fries_Rating.BackColor = System.Drawing.Color.Transparent;
            this.fries_Rating.Enabled = false;
            this.fries_Rating.ForeColor = System.Drawing.Color.Yellow;
            this.fries_Rating.Location = new System.Drawing.Point(448, 25);
            this.fries_Rating.Name = "fries_Rating";
            this.fries_Rating.Size = new System.Drawing.Size(184, 30);
            this.fries_Rating.TabIndex = 14;
            this.fries_Rating.Value = 0;
            this.fries_Rating.onValueChanged += new System.EventHandler(this.fries_Rating_onValueChanged);
            // 
            // L_5
            // 
            this.L_5.AutoSize = true;
            this.L_5.Font = new System.Drawing.Font("Microsoft JhengHei UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.L_5.ForeColor = System.Drawing.Color.Red;
            this.L_5.Location = new System.Drawing.Point(702, 133);
            this.L_5.Name = "L_5";
            this.L_5.Size = new System.Drawing.Size(131, 15);
            this.L_5.TabIndex = 13;
            this.L_5.Text = " Added To Favorites!";
            this.L_5.Visible = false;
            // 
            // flag_5
            // 
            this.flag_5.AutoSize = true;
            this.flag_5.Font = new System.Drawing.Font("Microsoft JhengHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.flag_5.ForeColor = System.Drawing.Color.Red;
            this.flag_5.Location = new System.Drawing.Point(688, 104);
            this.flag_5.Name = "flag_5";
            this.flag_5.Size = new System.Drawing.Size(166, 20);
            this.flag_5.TabIndex = 12;
            this.flag_5.Text = "Item Added To Cart!";
            this.flag_5.Visible = false;
            // 
            // fries_button
            // 
            this.fries_button.BackColor = System.Drawing.Color.White;
            this.fries_button.FlatAppearance.BorderSize = 0;
            this.fries_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.fries_button.Font = new System.Drawing.Font("Microsoft JhengHei UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fries_button.ForeColor = System.Drawing.Color.Gold;
            this.fries_button.Location = new System.Drawing.Point(705, 20);
            this.fries_button.Name = "fries_button";
            this.fries_button.Size = new System.Drawing.Size(134, 30);
            this.fries_button.TabIndex = 7;
            this.fries_button.Text = "Add To Cart";
            this.fries_button.UseVisualStyleBackColor = false;
            this.fries_button.Click += new System.EventHandler(this.fries_button_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.White;
            this.label11.Font = new System.Drawing.Font("Microsoft JhengHei UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Gold;
            this.label11.Location = new System.Drawing.Point(736, 53);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(85, 26);
            this.label11.TabIndex = 6;
            this.label11.Text = "Rs. 200";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft JhengHei UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Gold;
            this.label5.Location = new System.Drawing.Point(271, 20);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(172, 35);
            this.label5.TabIndex = 6;
            this.label5.Text = "French Fries";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // friesFav_button
            // 
            this.friesFav_button.BackColor = System.Drawing.Color.White;
            this.friesFav_button.FlatAppearance.BorderSize = 0;
            this.friesFav_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.friesFav_button.Image = ((System.Drawing.Image)(resources.GetObject("friesFav_button.Image")));
            this.friesFav_button.Location = new System.Drawing.Point(11, 0);
            this.friesFav_button.Margin = new System.Windows.Forms.Padding(0);
            this.friesFav_button.Name = "friesFav_button";
            this.friesFav_button.Size = new System.Drawing.Size(39, 33);
            this.friesFav_button.TabIndex = 11;
            this.friesFav_button.UseVisualStyleBackColor = false;
            this.friesFav_button.Click += new System.EventHandler(this.friesFav_button_Click);
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackColor = System.Drawing.Color.Gold;
            this.pictureBox5.Image = global::Foodie_menu.Resource1.fries;
            this.pictureBox5.Location = new System.Drawing.Point(63, 20);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(202, 162);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 1;
            this.pictureBox5.TabStop = false;
            this.pictureBox5.Click += new System.EventHandler(this.pictureBox5_Click);
            // 
            // pastaFav_button
            // 
            this.pastaFav_button.BackColor = System.Drawing.Color.White;
            this.pastaFav_button.FlatAppearance.BorderSize = 0;
            this.pastaFav_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.pastaFav_button.Image = ((System.Drawing.Image)(resources.GetObject("pastaFav_button.Image")));
            this.pastaFav_button.Location = new System.Drawing.Point(14, 0);
            this.pastaFav_button.Margin = new System.Windows.Forms.Padding(0);
            this.pastaFav_button.Name = "pastaFav_button";
            this.pastaFav_button.Size = new System.Drawing.Size(39, 33);
            this.pastaFav_button.TabIndex = 8;
            this.pastaFav_button.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.pastaFav_button.UseVisualStyleBackColor = false;
            this.pastaFav_button.Click += new System.EventHandler(this.pastaFv_button_Click);
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox4.Image = global::Foodie_menu.Resource1.pasta;
            this.pictureBox4.Location = new System.Drawing.Point(63, 25);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(202, 162);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 1;
            this.pictureBox4.TabStop = false;
            // 
            // sandwhichFav_button
            // 
            this.sandwhichFav_button.BackColor = System.Drawing.Color.White;
            this.sandwhichFav_button.FlatAppearance.BorderSize = 0;
            this.sandwhichFav_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.sandwhichFav_button.Image = ((System.Drawing.Image)(resources.GetObject("sandwhichFav_button.Image")));
            this.sandwhichFav_button.Location = new System.Drawing.Point(11, 1);
            this.sandwhichFav_button.Margin = new System.Windows.Forms.Padding(0);
            this.sandwhichFav_button.Name = "sandwhichFav_button";
            this.sandwhichFav_button.Size = new System.Drawing.Size(39, 33);
            this.sandwhichFav_button.TabIndex = 9;
            this.sandwhichFav_button.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.sandwhichFav_button.UseVisualStyleBackColor = false;
            this.sandwhichFav_button.Click += new System.EventHandler(this.sandwhichFav_button_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox3.Image = global::Foodie_menu.Resource1.sandwhich;
            this.pictureBox3.Location = new System.Drawing.Point(63, 27);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(202, 162);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 1;
            this.pictureBox3.TabStop = false;
            // 
            // burgerFav_button
            // 
            this.burgerFav_button.BackColor = System.Drawing.Color.White;
            this.burgerFav_button.FlatAppearance.BorderSize = 0;
            this.burgerFav_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.burgerFav_button.Image = ((System.Drawing.Image)(resources.GetObject("burgerFav_button.Image")));
            this.burgerFav_button.Location = new System.Drawing.Point(11, 1);
            this.burgerFav_button.Margin = new System.Windows.Forms.Padding(0);
            this.burgerFav_button.Name = "burgerFav_button";
            this.burgerFav_button.Size = new System.Drawing.Size(39, 33);
            this.burgerFav_button.TabIndex = 10;
            this.burgerFav_button.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.burgerFav_button.UseVisualStyleBackColor = false;
            this.burgerFav_button.Click += new System.EventHandler(this.burgerFav_buton_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.Image = global::Foodie_menu.Resource1.burger;
            this.pictureBox2.Location = new System.Drawing.Point(63, 28);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(202, 162);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = global::Foodie_menu.Resource1.pizza;
            this.pictureBox1.Location = new System.Drawing.Point(63, 20);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(202, 162);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // pizzaFav_button
            // 
            this.pizzaFav_button.BackColor = System.Drawing.Color.White;
            this.pizzaFav_button.FlatAppearance.BorderSize = 0;
            this.pizzaFav_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.pizzaFav_button.Image = ((System.Drawing.Image)(resources.GetObject("pizzaFav_button.Image")));
            this.pizzaFav_button.Location = new System.Drawing.Point(11, 1);
            this.pizzaFav_button.Margin = new System.Windows.Forms.Padding(0);
            this.pizzaFav_button.Name = "pizzaFav_button";
            this.pizzaFav_button.Size = new System.Drawing.Size(39, 33);
            this.pizzaFav_button.TabIndex = 5;
            this.pizzaFav_button.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.pizzaFav_button.UseVisualStyleBackColor = false;
            this.pizzaFav_button.Click += new System.EventHandler(this.pizzaFav_button_Click);
            // 
            // exclusive1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "exclusive1";
            this.Size = new System.Drawing.Size(856, 505);
            this.Load += new System.EventHandler(this.exclusive_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button pizza_button;
        private System.Windows.Forms.Button burger_button;
        private System.Windows.Forms.Button sandwhich_button;
        private System.Windows.Forms.Button pasta_button;
        private System.Windows.Forms.Button fries_button;
        private System.Windows.Forms.Button pizzaFav_button;
        private System.Windows.Forms.Button burgerFav_button;
        private System.Windows.Forms.Button sandwhichFav_button;
        private System.Windows.Forms.Button pastaFav_button;
        private System.Windows.Forms.Button friesFav_button;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label flag_1;
        private System.Windows.Forms.Label flag_4;
        private System.Windows.Forms.Label flag_3;
        private System.Windows.Forms.Label flag_2;
        private System.Windows.Forms.Label flag_5;
        private System.Windows.Forms.Label L_1;
        private System.Windows.Forms.Label L_4;
        private System.Windows.Forms.Label L_3;
        private System.Windows.Forms.Label L_2;
        private System.Windows.Forms.Label L_5;
        private Bunifu.Framework.UI.BunifuRating pizza_Rating;
        private Bunifu.Framework.UI.BunifuRating burger_Rating;
        private Bunifu.Framework.UI.BunifuRating sandwhich_Rating;
        private Bunifu.Framework.UI.BunifuRating pasta_Rating;
        private Bunifu.Framework.UI.BunifuRating fries_Rating;
    }
}

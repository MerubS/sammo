﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Foodie_menu
{
    public partial class favorite2 : UserControl
    {

        myCart2 obj = new myCart2();

        public favorite2()
        {
            InitializeComponent();
        }


        public void work()                 /// Updates UI whenever favorite tab is clicked
        {
            favList.Items.Clear();

            for(int i=0;i<myCart2.index2_2;i++)
            {
                favList.Items.Add(myCart2.favorites_2[i]);
            }
        }        // Updates Ui whenever favorite tab is clicked
        private void remove_button_Click(object sender, EventArgs e)
        {
            if (favList.SelectedItem != null)
            {
                obj.removeFavorite(favList.SelectedItem.ToString());
                favList.Items.Remove(favList.SelectedItem);
            }
            else
            {
                MessageBox.Show("Please Select An Item To Remove", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }   // Removes item from favorites

        private void favList_SelectedIndexChanged(object sender, EventArgs e)
        {
            item_picture.Visible = true;
            string item =  (string)favList.SelectedItem;
            if(item == "Latte") { item_picture.Image = Resource1.latte;}
            if (item == "Capuccino") { item_picture.Image = Resource1.cappucino; }
            if (item == "Cortado") { item_picture.Image = Resource1.cortado; }
            if (item == "Mocha") { item_picture.Image = Resource1.mocha; }
            if (item == "Americano") { item_picture.Image = Resource1.americano; }
            if (item == "Lungo") { item_picture.Image = Resource1.lungo; }
            if (item == "Black Coffee") { item_picture.Image = Resource1.black_coffee; }
            if (item == "Espresso") { item_picture.Image = Resource1.espresso; }
            if (item == "Tea") { item_picture.Image = Resource1.tea; }
            if (item == "Mazagran") { item_picture.Image = Resource1.mazaagran; }
        }    // Updtaes picture in picture box

        private void cart_button_Click(object sender, EventArgs e)
        {
            if(favList.SelectedItem != null)
            {
                obj.addItem(favList.SelectedItem.ToString());
                flag.Visible = true;
                timer1.Start();
            }
            else
            {
                MessageBox.Show("Please Select An Item To Add To Cart", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }       // Adds items to cart

        private void timer1_Tick(object sender, EventArgs e)          // Timer for label
        {
            flag.Visible = false;
            timer1.Stop();
        }

        private void favorite2_Load(object sender, EventArgs e)
        {

        }
    }
}
